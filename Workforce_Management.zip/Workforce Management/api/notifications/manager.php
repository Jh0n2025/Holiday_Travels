<?php
declare(strict_types=1);

require_once __DIR__ . '/../auth/session_guard.php';
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json; charset=utf-8');

$managerUser = requireRole('manager');

$managerEmployeeId = trim(
    (string)($managerUser['employee_id'] ?? '')
);

if ($managerEmployeeId === '') {
    http_response_code(401);

    echo json_encode([
        'success' => false,
        'message' => 'Manager session not found.'
    ]);

    exit;
}

try {

    /*
     * Find the manager's employee record.
     */
    $managerStmt = $pdo->prepare("
        SELECT id
        FROM employees
        WHERE employee_id = :employee_id
        LIMIT 1
    ");

    $managerStmt->execute([
        ':employee_id' => $managerEmployeeId
    ]);

    $manager = $managerStmt->fetch(
        PDO::FETCH_ASSOC
    );

    if (!$manager) {
        http_response_code(404);

        echo json_encode([
            'success' => false,
            'message' => 'Manager record not found.'
        ]);

        exit;
    }

    $managerId = (int)$manager['id'];

    /*
     * Pending team leave requests.
     */
    $leaveStmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM leave_requests lr
        INNER JOIN employees e
            ON e.employee_id = lr.employee_id
        WHERE e.manager_id = :manager_id
          AND lr.status = 'pending'
    ");

    $leaveStmt->execute([
        ':manager_id' => $managerId
    ]);

    $pendingLeave =
        (int)$leaveStmt->fetchColumn();

    /*
     * Pending team shift requests.
     */
    $shiftStmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM shift_requests sr
        INNER JOIN employees e
            ON e.employee_id = sr.employee_id
        WHERE e.manager_id = :manager_id
          AND sr.status = 'pending'
    ");

    $shiftStmt->execute([
        ':manager_id' => $managerId
    ]);

    $pendingShift =
        (int)$shiftStmt->fetchColumn();

    $notifications = [
        [
            'type' => 'analytics',
            'title' => 'Workforce analytics',
            'message' =>
                'Open the team attendance analytics and review current workforce activity.',
            'unread' => false
        ],
        [
            'type' => 'leave',
            'title' => 'Leave requests',
            'message' =>
                $pendingLeave > 0
                    ? "{$pendingLeave} leave request" .
                      ($pendingLeave === 1 ? '' : 's') .
                      " currently pending review."
                    : 'No pending leave requests. Open Leave Management to review team requests.',
            'unread' => $pendingLeave > 0
        ],
        [
            'type' => 'schedule',
            'title' => 'Team schedule',
            'message' =>
                $pendingShift > 0
                    ? "{$pendingShift} shift request" .
                      ($pendingShift === 1 ? '' : 's') .
                      " need your review."
                    : 'Open the team schedule to review assignments and shift requests.',
            'unread' => $pendingShift > 0
        ]
    ];

    $unreadCount =
        $pendingLeave +
        $pendingShift;

    echo json_encode([
        'success' => true,
        'unread_count' => $unreadCount,
        'data' => $notifications
    ]);

} catch (Throwable $e) {

    error_log(
        'Manager notification API failed: ' .
        $e->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'message' =>
            'Unable to load manager notifications.'
    ]);
}