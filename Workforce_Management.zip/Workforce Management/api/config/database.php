<?php

declare(strict_types=1);
/*
|--------------------------------------------------------------------------
| DATABASE SETTINGS
|--------------------------------------------------------------------------
| For XAMPP/Laragon local development:
| Host     = localhost
| Username = root
| Password = empty
| Database = workforce_management
|
| Change these values when you deploy to your real hosting server.
|--------------------------------------------------------------------------
*/

$db_host = 'localhost';
$db_name = 'workforce_management';
$db_user = 'root';
$db_pass = '';

$db_charset = 'utf8mb4';


/*
|--------------------------------------------------------------------------
| PDO CONNECTION
|--------------------------------------------------------------------------
*/

$dsn = "mysql:host={$db_host};dbname={$db_name};charset={$db_charset}";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];


try {

    $pdo = new PDO(
        $dsn,
        $db_user,
        $db_pass,
        $options
    );

} catch (PDOException $e) {

    http_response_code(500);

    die('Database connection failed.');

}