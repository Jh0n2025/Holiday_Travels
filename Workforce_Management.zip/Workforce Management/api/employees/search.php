<?php

declare(strict_types=1);

require_once __DIR__ . '/../auth/session_guard.php';
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json; charset=utf-8');

requireRole('employee');

$query = trim((string)($_GET['q'] ?? ''));

if ($query === '') {
    echo json_encode([
        'success' => true,
        'data' => []
    ]);
    exit;
}

try {

    $search = '%' . $query . '%';

    $stmt = $pdo->prepare("
        SELECT
            employee_id,
            first_name,
            middle_name,
            last_name,
            department_name,
            position_name,
            employment_status
        FROM employees
        WHERE employee_id LIKE :employee_id
           OR first_name LIKE :first_name
           OR middle_name LIKE :middle_name
           OR last_name LIKE :last_name
           OR department_name LIKE :department_name
           OR position_name LIKE :position_name
        ORDER BY first_name ASC, last_name ASC
        LIMIT 10
    ");

    $stmt->execute([
        ':employee_id' => $search,
        ':first_name' => $search,
        ':middle_name' => $search,
        ':last_name' => $search,
        ':department_name' => $search,
        ':position_name' => $search
    ]);

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $data = [];

    foreach ($rows as $row) {

        $name = trim(
            implode(' ', array_filter([
                $row['first_name'] ?? '',
                $row['middle_name'] ?? '',
                $row['last_name'] ?? ''
            ]))
        );

        $data[] = [
            'employee_id' => $row['employee_id'],
            'name' => $name,
            'department' => $row['department_name'] ?? '',
            'position' => $row['position_name'] ?? '',
            'status' => $row['employment_status'] ?? ''
        ];
    }

    echo json_encode([
        'success' => true,
        'data' => $data
    ]);

} catch (Throwable $e) {

    error_log(
        'Employee search failed: ' .
        $e->getMessage()
    );

    http_response_code(500);

    echo json_encode([
        'success' => false,
        'message' => 'Unable to search employees.'
    ]);
}