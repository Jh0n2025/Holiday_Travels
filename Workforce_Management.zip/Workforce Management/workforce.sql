-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2026 at 09:34 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `workforce_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE `accounts` (
  `id` int(10) UNSIGNED NOT NULL,
  `employee_id` varchar(50) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin','manager','employee') NOT NULL,
  `status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `employee_id`, `email`, `password_hash`, `role`, `status`, `created_at`, `updated_at`) VALUES
(1, '26011001', 'faingasonjhonie@gmail.com', '$2y$12$Mq.XRV0ZMrAJN3kkzlbKseU60VZw1SuJ4z0CBl2oVl7c.AO4Xc0.m', 'admin', 'active', '2026-09-25 12:31:43', '2026-09-25 14:30:28'),
(2, '26011002', 'nicolemayo059@gmail.com', '$2y$12$7YWgsAhO1Odtn3bSYMneeOpz5oh4axNzUWG4oNCBvNOhSFq4zriXe', 'manager', 'active', '2026-09-25 12:31:43', '2026-09-25 14:30:28'),
(3, '26011003', 'ticalosonia4@gmail.com', '$2y$12$ErxZ07UZFnWWkuDhk4xATuIJDlkX6wXTwaCqt6r4lX.A9wMDMWkl.', 'employee', 'active', '2026-09-25 12:31:43', '2026-09-25 14:30:28');

-- --------------------------------------------------------

--
-- Table structure for table `attendance_records`
--

CREATE TABLE `attendance_records` (
  `id` int(10) UNSIGNED NOT NULL,
  `employee_id` varchar(50) NOT NULL,
  `attendance_date` date NOT NULL,
  `time_in` datetime DEFAULT NULL,
  `time_out` datetime DEFAULT NULL,
  `status` enum('present','late','absent','half_day','on_leave') NOT NULL DEFAULT 'present',
  `source` enum('kiosk','manual','system') NOT NULL DEFAULT 'system',
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `id` int(10) UNSIGNED NOT NULL,
  `employee_id` varchar(50) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `department_name` varchar(150) DEFAULT NULL,
  `position_name` varchar(150) DEFAULT NULL,
  `hire_date` date DEFAULT NULL,
  `address` text DEFAULT NULL,
  `employment_type` varchar(100) DEFAULT NULL,
  `employment_status` enum('active','inactive','on_leave','terminated') NOT NULL DEFAULT 'active',
  `manager_id` int(10) UNSIGNED DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `employee_id`, `first_name`, `middle_name`, `last_name`, `email`, `phone`, `department_name`, `position_name`, `hire_date`, `address`, `employment_type`, `employment_status`, `manager_id`, `created_at`, `updated_at`) VALUES
(1, '26011001', 'Admin', NULL, 'Account', 'faingasonjhonie@gmail.com', NULL, 'Management', 'System Administrator', NULL, NULL, 'REGULAR', 'active', NULL, '2026-09-25 14:29:43', '2026-09-25 14:29:43'),
(2, '26011002', 'Manager', NULL, 'Account', 'nicolemayo059@gmail.com', NULL, 'Operations', 'Operations Manager', NULL, NULL, 'REGULAR', 'active', NULL, '2026-09-25 14:29:43', '2026-09-25 14:29:43'),
(3, '26011003', 'Employee', NULL, 'Account', 'ticalosonia4@gmail.com', NULL, 'Operations', 'Tour Guide', NULL, NULL, 'REGULAR', 'active', NULL, '2026-09-25 14:29:43', '2026-09-25 14:29:43');

-- --------------------------------------------------------

--
-- Table structure for table `kiosk_log_entries`
--

CREATE TABLE `kiosk_log_entries` (
  `id` int(10) UNSIGNED NOT NULL,
  `employee_id` varchar(50) NOT NULL,
  `rfid_card_id` int(10) UNSIGNED DEFAULT NULL,
  `rfid_uid` varchar(100) NOT NULL,
  `kiosk_name` varchar(100) NOT NULL DEFAULT 'Main Kiosk',
  `scan_status` enum('APPROVED','DENIED') NOT NULL,
  `scanned_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `leave_requests`
--

CREATE TABLE `leave_requests` (
  `id` int(10) UNSIGNED NOT NULL,
  `employee_id` varchar(50) NOT NULL,
  `leave_type` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `reason` text DEFAULT NULL,
  `status` enum('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'pending',
  `approved_by` int(10) UNSIGNED DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `otp_challenges`
--

CREATE TABLE `otp_challenges` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `attempts` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `consumed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `otp_challenges`
--

INSERT INTO `otp_challenges` (`id`, `account_id`, `code_hash`, `expires_at`, `attempts`, `consumed_at`, `created_at`) VALUES
(2, 3, '$2y$10$DwfsRX3s8zPiM1XqtVaxmOl98iqcRGc3b73PYGSWPasP2Oj7mT2Hq', '2026-09-25 08:00:00', 0, '2026-09-25 13:50:37', '2026-09-25 13:50:00'),
(3, 3, '$2y$10$F.lW8Cy.b.hIsYo4ihMD7udiVw5CflgdbDSfro5OH.1COAZXLvMXG', '2026-09-25 08:00:37', 0, '2026-09-25 13:53:44', '2026-09-25 13:50:37'),
(4, 3, '$2y$10$8NWd8F8WicS0fDsSEG/rbuLSOwFULl00XZXlzxXclT1YL.u9tUDv2', '2026-09-25 08:03:45', 0, '2026-09-25 13:54:18', '2026-09-25 13:53:45'),
(5, 2, '$2y$10$Fq4Wi23MdBCtAudbAS53nOUxCwjgeCro3jLqjYc2FPHpD5VqqJgGG', '2026-09-25 08:04:39', 0, '2026-09-25 14:04:55', '2026-09-25 13:54:39'),
(6, 2, '$2y$10$NRezbVNCKoye7sqRnhBnUePnikqoxzYzYT5xDziQQLXU3Rgfj1zaK', '2026-09-25 08:14:55', 0, '2026-09-25 14:05:18', '2026-09-25 14:04:55'),
(7, 1, '$2y$10$XIpnwLYSBUxWbhL1CNOQX.7mepa2zkLH9o3vuFEKsY/LM3wTg3l22', '2026-09-25 08:17:04', 0, '2026-09-25 14:07:58', '2026-09-25 14:07:04'),
(8, 1, '$2y$10$VlGoACnrefPocpmx48JkpO9tJ6rWbR64Q3SUs5O9gVLZWjT9yAIUW', '2026-09-25 08:18:23', 0, '2026-09-25 14:08:46', '2026-09-25 14:08:23'),
(9, 3, '$2y$10$9gMtFIJfsDXvQWGVzBxIn.nSRDBZ0Gesu4oVH1XViNGw7heZmBQ4S', '2026-09-25 08:20:11', 0, '2026-09-25 14:10:33', '2026-09-25 14:10:11');

-- --------------------------------------------------------

--
-- Table structure for table `rfid_cards`
--

CREATE TABLE `rfid_cards` (
  `id` int(10) UNSIGNED NOT NULL,
  `employee_id` varchar(50) NOT NULL,
  `rfid_uid` varchar(100) NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rfid_cards`
--

INSERT INTO `rfid_cards` (`id`, `employee_id`, `rfid_uid`, `status`, `created_at`) VALUES
(1, '26011001', '3219410377', 'active', '2026-09-25 14:35:04'),
(2, '26011002', '3219246537', 'active', '2026-09-25 14:35:04'),
(3, '26011003', '3215545033', 'active', '2026-09-25 14:35:04');

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `id` int(10) UNSIGNED NOT NULL,
  `employee_id` varchar(50) NOT NULL,
  `schedule_date` date NOT NULL,
  `shift_name` varchar(100) DEFAULT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `status` enum('scheduled','completed','cancelled') NOT NULL DEFAULT 'scheduled',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shift_requests`
--

CREATE TABLE `shift_requests` (
  `id` int(10) UNSIGNED NOT NULL,
  `employee_id` varchar(50) NOT NULL,
  `requested_date` date NOT NULL,
  `requested_shift` varchar(100) NOT NULL,
  `reason` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `reviewed_by` int(10) UNSIGNED DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `timesheet_reviews`
--

CREATE TABLE `timesheet_reviews` (
  `id` int(10) UNSIGNED NOT NULL,
  `employee_id` varchar(50) NOT NULL,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `reviewed_by` int(10) UNSIGNED DEFAULT NULL,
  `reviewed_at` datetime DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trusted_devices`
--

CREATE TABLE `trusted_devices` (
  `id` int(10) UNSIGNED NOT NULL,
  `account_id` int(10) UNSIGNED NOT NULL,
  `device_token_hash` varchar(255) NOT NULL,
  `verified_at` datetime NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `last_used_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `trusted_devices`
--

INSERT INTO `trusted_devices` (`id`, `account_id`, `device_token_hash`, `verified_at`, `expires_at`, `created_at`, `last_used_at`) VALUES
(1, 3, '3a7bf2661a92ae943b1ac088b34b0900ebd961c7d503dfb95fa8799a67664533', '2026-09-25 13:54:18', '2026-09-26 13:54:18', '2026-09-25 13:54:18', '2026-09-25 13:54:18'),
(2, 2, '4281819d92087961cc106dbf72fe8c999772e8f14f9c8b0b023bf93ab7e506ec', '2026-09-25 14:05:18', '2026-09-26 14:05:18', '2026-09-25 14:05:18', '2026-09-25 14:05:18'),
(3, 1, 'c1196dce3a8ed084aac106eb1ab7846055a6dc364ec2a8977781a6eaa263c28c', '2026-09-25 14:07:58', '2026-09-26 14:07:58', '2026-09-25 14:07:58', '2026-09-25 15:07:00'),
(4, 1, 'bda62b20341ab6369a778941eafb9e7a597dd5349d4a1d9049034b1c8c7d9c69', '2026-09-25 14:08:46', '2026-09-26 14:08:46', '2026-09-25 14:08:46', '2026-09-25 14:08:46'),
(5, 3, '01ec4e78e490b848306ce1206d4a293ad2888a3fe530a4add0de7d0802fdd922', '2026-09-25 14:10:33', '2026-09-26 14:10:33', '2026-09-25 14:10:33', '2026-09-25 14:10:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_accounts_employee_id` (`employee_id`),
  ADD KEY `idx_accounts_role` (`role`),
  ADD KEY `idx_accounts_status` (`status`);

--
-- Indexes for table `attendance_records`
--
ALTER TABLE `attendance_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_attendance_employee` (`employee_id`),
  ADD KEY `idx_attendance_date` (`attendance_date`),
  ADD KEY `idx_attendance_status` (`status`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `employee_id` (`employee_id`),
  ADD KEY `idx_employees_employee_id` (`employee_id`),
  ADD KEY `idx_employees_department` (`department_name`),
  ADD KEY `idx_employees_status` (`employment_status`),
  ADD KEY `fk_employee_manager` (`manager_id`);

--
-- Indexes for table `kiosk_log_entries`
--
ALTER TABLE `kiosk_log_entries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_kiosk_employee` (`employee_id`),
  ADD KEY `idx_kiosk_rfid` (`rfid_uid`),
  ADD KEY `idx_kiosk_status` (`scan_status`),
  ADD KEY `idx_kiosk_time` (`scanned_at`),
  ADD KEY `fk_kiosk_rfid` (`rfid_card_id`);

--
-- Indexes for table `leave_requests`
--
ALTER TABLE `leave_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_leave_employee` (`employee_id`),
  ADD KEY `idx_leave_status` (`status`),
  ADD KEY `idx_leave_dates` (`start_date`,`end_date`),
  ADD KEY `fk_leave_approver` (`approved_by`);

--
-- Indexes for table `otp_challenges`
--
ALTER TABLE `otp_challenges`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_otp_account` (`account_id`),
  ADD KEY `idx_otp_expiration` (`expires_at`);

--
-- Indexes for table `rfid_cards`
--
ALTER TABLE `rfid_cards`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `rfid_uid` (`rfid_uid`),
  ADD KEY `idx_rfid_employee_id` (`employee_id`),
  ADD KEY `idx_rfid_status` (`status`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_schedule_employee` (`employee_id`),
  ADD KEY `idx_schedule_date` (`schedule_date`);

--
-- Indexes for table `shift_requests`
--
ALTER TABLE `shift_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_shift_employee` (`employee_id`),
  ADD KEY `idx_shift_status` (`status`),
  ADD KEY `fk_shift_reviewer` (`reviewed_by`);

--
-- Indexes for table `timesheet_reviews`
--
ALTER TABLE `timesheet_reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_timesheet_employee` (`employee_id`),
  ADD KEY `idx_timesheet_period` (`period_start`,`period_end`),
  ADD KEY `idx_timesheet_status` (`status`),
  ADD KEY `fk_timesheet_reviewer` (`reviewed_by`);

--
-- Indexes for table `trusted_devices`
--
ALTER TABLE `trusted_devices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_trusted_account` (`account_id`),
  ADD KEY `idx_trusted_expiration` (`expires_at`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `attendance_records`
--
ALTER TABLE `attendance_records`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `kiosk_log_entries`
--
ALTER TABLE `kiosk_log_entries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `leave_requests`
--
ALTER TABLE `leave_requests`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `otp_challenges`
--
ALTER TABLE `otp_challenges`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `rfid_cards`
--
ALTER TABLE `rfid_cards`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `shift_requests`
--
ALTER TABLE `shift_requests`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `timesheet_reviews`
--
ALTER TABLE `timesheet_reviews`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trusted_devices`
--
ALTER TABLE `trusted_devices`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `accounts`
--
ALTER TABLE `accounts`
  ADD CONSTRAINT `fk_accounts_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `attendance_records`
--
ALTER TABLE `attendance_records`
  ADD CONSTRAINT `fk_attendance_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `employees`
--
ALTER TABLE `employees`
  ADD CONSTRAINT `fk_employee_manager` FOREIGN KEY (`manager_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `kiosk_log_entries`
--
ALTER TABLE `kiosk_log_entries`
  ADD CONSTRAINT `fk_kiosk_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_kiosk_rfid` FOREIGN KEY (`rfid_card_id`) REFERENCES `rfid_cards` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `leave_requests`
--
ALTER TABLE `leave_requests`
  ADD CONSTRAINT `fk_leave_approver` FOREIGN KEY (`approved_by`) REFERENCES `accounts` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_leave_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `otp_challenges`
--
ALTER TABLE `otp_challenges`
  ADD CONSTRAINT `fk_otp_account` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rfid_cards`
--
ALTER TABLE `rfid_cards`
  ADD CONSTRAINT `fk_rfid_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `schedules`
--
ALTER TABLE `schedules`
  ADD CONSTRAINT `fk_schedule_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `shift_requests`
--
ALTER TABLE `shift_requests`
  ADD CONSTRAINT `fk_shift_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_shift_reviewer` FOREIGN KEY (`reviewed_by`) REFERENCES `accounts` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `timesheet_reviews`
--
ALTER TABLE `timesheet_reviews`
  ADD CONSTRAINT `fk_timesheet_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`employee_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_timesheet_reviewer` FOREIGN KEY (`reviewed_by`) REFERENCES `accounts` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `trusted_devices`
--
ALTER TABLE `trusted_devices`
  ADD CONSTRAINT `fk_trusted_account` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
